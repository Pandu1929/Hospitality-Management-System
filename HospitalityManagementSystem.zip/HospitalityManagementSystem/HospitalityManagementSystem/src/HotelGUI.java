import javax.swing.*;
import java.awt.event.*;

public class HotelGUI extends JFrame {

    JTextField nameField;
    JTextField locationField;
    JTextField amenitiesField;

    JButton addButton;

    public HotelGUI() {

        setTitle("Hotel Management");
        setSize(400,300);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel nameLabel = new JLabel("Hotel Name");
        nameLabel.setBounds(50,50,100,30);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(150,50,150,30);
        add(nameField);

        JLabel locationLabel = new JLabel("Location");
        locationLabel.setBounds(50,100,100,30);
        add(locationLabel);

        locationField = new JTextField();
        locationField.setBounds(150,100,150,30);
        add(locationField);

        JLabel amenitiesLabel = new JLabel("Amenities");
        amenitiesLabel.setBounds(50,150,100,30);
        add(amenitiesLabel);

        amenitiesField = new JTextField();
        amenitiesField.setBounds(150,150,150,30);
        add(amenitiesField);

        addButton = new JButton("Add Hotel");
        addButton.setBounds(150,200,120,30);
        add(addButton);

        addButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                String name = nameField.getText();
                String location = locationField.getText();
                String amenities = amenitiesField.getText();

                HotelDAO dao = new HotelDAO();
                dao.addHotel(name, location, amenities);

                JOptionPane.showMessageDialog(null,"Hotel Added Successfully");

            }
        });

        setVisible(true);
    }

}
