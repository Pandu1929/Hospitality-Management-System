import java.sql.Connection;
import java.sql.PreparedStatement;

public class GuestDAO {

    public void addGuest(String name, String email, String phone) {

        try {

            Connection con = DatabaseConnector.getConnection();

            String query = "INSERT INTO Guests(name, email, phone) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);

            ps.executeUpdate();

            System.out.println("Guest added successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}