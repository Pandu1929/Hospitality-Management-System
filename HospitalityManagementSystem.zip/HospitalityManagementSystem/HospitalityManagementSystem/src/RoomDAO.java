import java.sql.Connection;
import java.sql.PreparedStatement;

public class RoomDAO {

    public void addRoom(int hotelId, int roomNumber, String type, double price, String status) {

        try {

            Connection con = DatabaseConnector.getConnection();

            String query = "INSERT INTO Rooms(hotel_id, room_number, type, price, status) VALUES(?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, hotelId);
            ps.setInt(2, roomNumber);
            ps.setString(3, type);
            ps.setDouble(4, price);
            ps.setString(5, status);

            ps.executeUpdate();

            System.out.println("Room added successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
