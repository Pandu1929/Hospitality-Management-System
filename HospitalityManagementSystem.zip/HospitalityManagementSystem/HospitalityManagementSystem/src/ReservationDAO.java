import java.sql.Connection;
import java.sql.PreparedStatement;

public class ReservationDAO {

    public void addReservation(int guestId, int roomId, String checkIn, String checkOut) {

        try {

            Connection con = DatabaseConnector.getConnection();

            String query = "INSERT INTO Reservations(guest_id, room_id, check_in, check_out) VALUES(?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, guestId);
            ps.setInt(2, roomId);
            ps.setString(3, checkIn);
            ps.setString(4, checkOut);

            ps.executeUpdate();

            System.out.println("Reservation added successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}