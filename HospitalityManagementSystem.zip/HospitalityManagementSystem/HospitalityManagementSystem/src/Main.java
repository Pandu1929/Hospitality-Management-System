import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        while(true) {

            System.out.println("----- Hospitality Management System -----");
            System.out.println("1. Add Hotel");
            System.out.println("2. Add Room");
            System.out.println("3. Add Guest");
            System.out.println("4. Make Reservation");
            System.out.println("5. Exit");

            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch(choice) {

                case 1:

                    System.out.print("Enter Hotel Name: ");
                    String hname = sc.nextLine();

                    System.out.print("Enter Location: ");
                    String location = sc.nextLine();

                    System.out.print("Enter Amenities: ");
                    String amenities = sc.nextLine();

                    HotelDAO hdao = new HotelDAO();
                    hdao.addHotel(hname, location, amenities);

                    break;

                case 2:

                    System.out.print("Enter Hotel ID: ");
                    int hid = sc.nextInt();

                    System.out.print("Enter Room Number: ");
                    int rnum = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Room Type: ");
                    String type = sc.nextLine();

                    System.out.print("Enter Price: ");
                    double price = sc.nextDouble();
                    sc.nextLine();

                    System.out.print("Enter Status: ");
                    String status = sc.nextLine();

                    RoomDAO rdao = new RoomDAO();
                    rdao.addRoom(hid, rnum, type, price, status);

                    break;

                case 3:

                    System.out.print("Enter Guest Name: ");
                    String gname = sc.nextLine();

                    System.out.print("Enter Email: ");
                    String email = sc.nextLine();

                    System.out.print("Enter Phone: ");
                    String phone = sc.nextLine();

                    GuestDAO gdao = new GuestDAO();
                    gdao.addGuest(gname, email, phone);

                    break;

                case 4:

                    System.out.print("Enter Guest ID: ");
                    int gid = sc.nextInt();

                    System.out.print("Enter Room ID: ");
                    int rid = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Check-in Date (YYYY-MM-DD): ");
                    String checkin = sc.nextLine();

                    System.out.print("Enter Check-out Date (YYYY-MM-DD): ");
                    String checkout = sc.nextLine();

                    ReservationDAO resdao = new ReservationDAO();
                    resdao.addReservation(gid, rid, checkin, checkout);

                    break;

                case 5:

                    System.out.println("Thank You!");
                    System.exit(0);

                default:

                    System.out.println("Invalid choice");

            }

        }

    }

}