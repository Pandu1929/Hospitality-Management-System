import java.sql.Connection;
import java.sql.PreparedStatement;

public class HotelDAO {

    public void addHotel(String name, String location, String amenities) {

        try {

            Connection con = DatabaseConnector.getConnection();

            String query = "INSERT INTO Hotels(name,location,amenities) VALUES(?,?,?)";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, name);
            ps.setString(2, location);
            ps.setString(3, amenities);

            ps.executeUpdate();

            System.out.println("Hotel added successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
